-- kcl_accueil.lua
Citizen.CreateThread(function()
  while ESX == nil do
	TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
	Citizen.Wait(6000)
  end
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
  ESX.PlayerData = xPlayer
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
  ESX.PlayerData.job = job
end)

function KeyboardInput(TextEntry, ExampleText, MaxStringLenght)
    AddTextEntry('FMMC_KEY_TIP1', TextEntry) 
    blockinput = true 
    DisplayOnscreenKeyboard(1, "FMMC_KEY_TIP1", "Somme", ExampleText, "", "", "", MaxStringLenght) 
    while UpdateOnscreenKeyboard() ~= 1 and UpdateOnscreenKeyboard() ~= 2 do 
        Citizen.Wait(0)
    end 
    if UpdateOnscreenKeyboard() ~= 2 then
        local result = GetOnscreenKeyboardResult()
        Citizen.Wait(500) 
        blockinput = false
        return result 
    else
        Citizen.Wait(500) 
        blockinput = false 
        return nil 
    end
end

-- [Menu RageUi V2]
local open = false 
local kbennysaccueil = RageUI.CreateMenu("Homepage", "benny's",0,100,nil,nil)
local kbennysaccueil2 = RageUI.CreateMenu("Homepage", "benny's",0,100,nil,nil)
kbennysaccueil.Display.Header = true 
kbennysaccueil.Closed = function()
  open = false
  nomprenom = nil
  numero = nil
  heurerdv = nil
  rdvmotif = nil
end

-- [Fonction du Menu]
function OpenMenuAccueilkbennys() 
    if open then 
		open = false
		RageUI.Visible(kbennysaccueil, false)
		return
	else
		open = true 
		RageUI.Visible(kbennysaccueil, true)
		CreateThread(function()
		while open do 
        RageUI.IsVisible(kbennysaccueil, function()

            RageUI.Button("Call a bennys employee", nil, {RightLabel = "→→"}, not codesCooldown5 , {
                onSelected = function()
                codesCooldown5 = true 
            TriggerServerEvent('Appel:kbennys')
            ESX.ShowNotification("You have just sent a notification to the employees of the bennys.")
            Citizen.SetTimeout(5000, function() codesCooldown5 = false end)
        end})
            RageUI.Button("Make an appointment", nil, {RightLabel = "→→"}, true , {
                onSelected = function()
        end}, kbennysaccueil2)     
      end)    
         
        RageUI.IsVisible(kbennysaccueil2, function()    

            RageUI.Button("Last name and First Name", nil, {RightLabel = nomprenom}, true , {
                onSelected = function()
                DisplayOnscreenKeyboard(1, "FMMC_MPM_NA", "Last name and First Name", " ", "", "", "", 20)
                while (UpdateOnscreenKeyboard() == 0) do
                    DisableAllControlActions(0);
                   Citizen.Wait(1)
                end
                if (GetOnscreenKeyboardResult()) then
                    nomprenom = GetOnscreenKeyboardResult() 
                end
             end})

            RageUI.Button("Phone Number", nil, {RightLabel = numero}, true , {
                onSelected = function()
                    DisplayOnscreenKeyboard(1, "FMMC_MPM_NA", "555-", "555-", "", "", "", 10)
                    while (UpdateOnscreenKeyboard() == 0) do
                        DisableAllControlActions(0);
                       Citizen.Wait(1)
                    end
                    if (GetOnscreenKeyboardResult()) then
                        numero = GetOnscreenKeyboardResult()  
            		end
                end})

            RageUI.Button("Meeting time", nil, {RightLabel = heurerdv}, true , {
                onSelected = function()
                    DisplayOnscreenKeyboard(1, "FMMC_MPM_NA", "15h40", " ", "", "", "", 10)
                    while (UpdateOnscreenKeyboard() == 0) do
                        DisableAllControlActions(0);
                       Citizen.Wait(1)
                    end
                    if (GetOnscreenKeyboardResult()) then
                        heurerdv = GetOnscreenKeyboardResult()  
                    end
                end})
            
            RageUI.Button("Reason for the appointment", nil, {RightLabel = "→→"}, true , {
                onSelected = function()
                    DisplayOnscreenKeyboard(1, "FMMC_MPM_NA", "Reason", " ", "", "", "", 120)
                    while (UpdateOnscreenKeyboard() == 0) do
                        DisableAllControlActions(0);
                       Citizen.Wait(1)
                    end
                    if (GetOnscreenKeyboardResult()) then
                        rdvmotif = GetOnscreenKeyboardResult()  
                    end
                end})

            RageUI.Button("Validate the request", nil, { Color = {BackgroundColor = { 230, 119, 14 , 50}} }, true, {
                onSelected = function()
                    if (nomprenom == nil or nomprenom == '') then
                        ESX.ShowNotification('~r~You have not filled in your Name / First name')
                    elseif (numero == nil or numero == '') then
                        ESX.ShowNotification('~r~You didn\'t fill in your phone number')
                    elseif (heurerdv == nil or heurerdv == '') then
                        ESX.ShowNotification('~r~You did not fill the meeting time')
                    elseif (rdvmotif == nil or rdvmotif == '' or rdvmotif == "Motif") then
                        ESX.ShowNotification('~r~You did not fill in the reason for the appointment')
                else
                    RageUI.CloseAll()
                    TriggerServerEvent("Rdv:kbennysMotif", nomprenom, numero, heurerdv, rdvmotif)
                    ESX.ShowNotification("Appointment request sent")
                    nomprenom = nil
                    numero = nil
                    heurerdv = nil
                    rdvmotif = nil
                end
            end}) 
          end)			
		Wait(0)
	   end
	end)
 end
end

-- [Ouverture Du Menu]
Citizen.CreateThread(function()
    while true do 
        local wait = 750
         for k in pairs(Config.Position.Accueil) do 
                local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
                local pos = Config.Position.Accueil
                local dist = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, pos[k].x, pos[k].y, pos[k].z)
             if dist <= 2.0 then 
                    wait = 0
                    Visual.Subtitle(Config.TextAccueil, 1)
                    if IsControlJustPressed(1,51) then
                        OpenMenuAccueilkbennys()
                    end
                end
            end
    Citizen.Wait(wait)
   end
end)

-- kbennys by ! Kamion#1323