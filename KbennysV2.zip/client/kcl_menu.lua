
Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(6000)
	end
  while ESX.GetPlayerData().job == nil do
		Citizen.Wait(10)
    end
    if ESX.IsPlayerLoaded() then
  ESX.PlayerData = ESX.GetPlayerData()
  end
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
	ESX.PlayerData = xPlayer
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
	ESX.PlayerData.job = job
end)

function KeyboardInput(TextEntry, ExampleText, MaxStringLenght)
    AddTextEntry('FMMC_KEY_TIP1', TextEntry) 
    DisplayOnscreenKeyboard(1, "FMMC_KEY_TIP1", "", ExampleText, "", "", "", MaxStringLenght)
    blockinput = true
    while UpdateOnscreenKeyboard() ~= 1 and UpdateOnscreenKeyboard() ~= 2 do 
        Citizen.Wait(0)
    end
    if UpdateOnscreenKeyboard() ~= 2 then
        local result = GetOnscreenKeyboardResult() 
        Citizen.Wait(500) 
        blockinput = false
        return result 
    else
        Citizen.Wait(500) 
        blockinput = false 
        return nil 
    end
end

-- [Menu RageUi V2]
local open = false 
local kbennysmenurageuiv2 = RageUI.CreateMenu("Benny's", 'motorworks',0,100,nil,nil)
local kbennyssubmenurageuiv2 = RageUI.CreateSubMenu(kbennysmenurageuiv2, nil, "bennys")
local kbennymecanossubmenurageuiv2 = RageUI.CreateSubMenu(kbennysmenurageuiv2, nil, "bennys")
kbennysmenurageuiv2.Display.Header = true 
kbennysmenurageuiv2.Closed = function()
  open = false
end

-- [Fonction du Menu ]
function OpenMenukbennys()
	if open then 
		open = false
		RageUI.Visible(kbennysmenurageuiv2, false)
		return
	else
		open = true 
		RageUI.Visible(kbennysmenurageuiv2, true)
		CreateThread(function()
		while open do 
		   RageUI.IsVisible(kbennysmenurageuiv2,function()
			RageUI.Checkbox("Take your service", nil, servicekbennys, {}, {
                onChecked = function(index, items)
                    servicekbennys = true
					ESX.ShowNotification("~g~You took your service !")
                    TriggerServerEvent('kbennys:prisedeservice')
                end,
                onUnChecked = function(index, items)
                    servicekbennys = false
					ESX.ShowNotification("~r~You have left your service !")
                    TriggerServerEvent('kbennys:quitteleservice')
                end})
	if servicekbennys then

           RageUI.Separator("~o~↓ Advertisement ↓")

            RageUI.Button("Advertisement bennys", nil, {RightLabel = "→→"}, true , {
                  onSelected = function()
                end}, kbennyssubmenurageuiv2 )      
            
                RageUI.Button("Repair", nil, {RightLabel = "→→"}, true , {
                    onSelected = function()
                  end}, kbennymecanossubmenurageuiv2)    
           
            RageUI.Button("Make an Invoice", nil, {RightLabel = "→→"}, true , {
                onSelected = function()
                    amount = KeyboardInput("Invoice amount",nil,3)
                    amount = tonumber(amount)
                    local player, distance = ESX.Game.GetClosestPlayer()
                    if player ~= -1 and distance <= 3.0 then
                    if amount == nil then
                        ESX.ShowNotification("~r~Problems~s~: Invalid amount")
                    else
                        local playerPed        = PlayerPedId() 
                        Citizen.Wait(5000)
                        TriggerServerEvent('esx_billing:sendBill', GetPlayerServerId(player), 'society_bennys', ('bennys'), amount)
                        Citizen.Wait(100)
                        ESX.ShowNotification("~g~You have sent the invoice")
                    end
                    else
                    ESX.ShowNotification("~r~Problems~s~: No player nearby")
                    end
                end});
             end
        end)

    RageUI.IsVisible(kbennyssubmenurageuiv2 ,function() 

           RageUI.Button("Advertisement ~g~[Openings]", nil, {RightLabel = "→"}, true , {
			onSelected = function()
				TriggerServerEvent('Ouvre:kbennys')
			end
		})

		RageUI.Button("Advertisement ~r~[Closures]", nil, {RightLabel = "→"}, true , {
			onSelected = function()
				TriggerServerEvent('Ferme:kbennys')
			end
		})

		RageUI.Button("Advertisement ~y~[Recruitment]", nil, {RightLabel = "→"}, true , {
			onSelected = function()
				TriggerServerEvent('Recru:kbennys')
			end
		})
    end)


        RageUI.IsVisible(kbennymecanossubmenurageuiv2,function() 

			RageUI.Button("Repair the vehicle", nil, {RightLabel = "→→"}, true, {
				onSelected = function()
					local playerPed = PlayerPedId()
					local vehicle   = ESX.Game.GetVehicleInDirection()
					local coords    = GetEntityCoords(playerPed)
		
					if IsPedSittingInAnyVehicle(playerPed) then
						ESX.ShowNotification('Get out of the car')
						return
					end
		
					if DoesEntityExist(vehicle) then
						isBusy = true
						TaskStartScenarioInPlace(playerPed, 'PROP_HUMAN_BUM_BIN', 0, true)
						Citizen.CreateThread(function()
							Citizen.Wait(20000)
		
							SetVehicleFixed(vehicle)
							SetVehicleDeformationFixed(vehicle)
							SetVehicleUndriveable(vehicle, false)
							SetVehicleEngineOn(vehicle, true, true)
							ClearPedTasksImmediately(playerPed)
		
							ESX.ShowNotification('The car is repaired')
							isBusy = false
						end)
					else
						ESX.ShowNotification('No vehicle nearby')
					end
		 
				end,}) 
				
				RageUI.Button("Clean vehicle", nil, {RightLabel = "→→"}, true , {
					onSelected = function()
						local playerPed = PlayerPedId()
						local vehicle   = ESX.Game.GetVehicleInDirection()
						local coords    = GetEntityCoords(playerPed)
			
						if IsPedSittingInAnyVehicle(playerPed) then
							ESX.ShowNotification('Get out of the car')
							return
						end
			
						if DoesEntityExist(vehicle) then
							isBusy = true
							TaskStartScenarioInPlace(playerPed, 'WORLD_HUMAN_MAID_CLEAN', 0, true)
							Citizen.CreateThread(function()
								Citizen.Wait(10000)
			
								SetVehicleDirtLevel(vehicle, 0)
								ClearPedTasksImmediately(playerPed)
			
								ESX.ShowNotification('Cleaned car')
								isBusy = false
							end)
						else
							ESX.ShowNotification('No vehicle nearby')
						end
						end,})

								RageUI.Button("Crochet vehicle", nil, {RightLabel = "→→"}, true , {
				onSelected = function()
						local playerPed = PlayerPedId()
						local vehicle = ESX.Game.GetVehicleInDirection()
						local coords = GetEntityCoords(playerPed)
			
						if IsPedSittingInAnyVehicle(playerPed) then
							ESX.ShowNotification('Impossible action')
							return
						end
			
						if DoesEntityExist(vehicle) then
							isBusy = true
							TaskStartScenarioInPlace(playerPed, 'WORLD_HUMAN_WELDING', 0, true)
							Citizen.CreateThread(function()
								Citizen.Wait(10000)
			
								SetVehicleDoorsLocked(vehicle, 1)
								SetVehicleDoorsLockedForAllPlayers(vehicle, false)
								ClearPedTasksImmediately(playerPed)
			
								ESX.ShowNotification('Unlocked vehicle')
								isBusy = false
							end)
						else
							ESX.ShowNotification('No car around')
						end
				end,})
						
				   RageUI.Button("Impound vehicle", nil, {RightLabel = "→→"}, true , {
					onSelected = function()
						local playerPed = PlayerPedId()

						if IsPedSittingInAnyVehicle(playerPed) then
							local vehicle = GetVehiclePedIsIn(playerPed, false)
			
							if GetPedInVehicleSeat(vehicle, -1) == playerPed then
								ESX.ShowNotification('The car was impounded')
								ESX.Game.DeleteVehicle(vehicle)
							   
							else
								ESX.ShowNotification('Get out of the car')
							end
						else
							local vehicle = ESX.Game.GetVehicleInDirection()
			
							if DoesEntityExist(vehicle) then
								TaskStartScenarioInPlace(playerPed, 'CODE_HUMAN_MEDIC_TIME_OF_DEATH', 0, true)
							Citizen.CreateThread(function()
								Citizen.Wait(10000)
								ClearPedTasks(playerPed)
                                Citizen.Wait(5000)
								ESX.ShowNotification('The car was impounded')
								ESX.Game.DeleteVehicle(vehicle)
								end)
							else
								ESX.ShowNotification('No car around')
							end
						 end
				    end,})
                 end)
           Wait(0)
         end
      end)
    end
 end

-- [Ouverture du Menu]
Keys.Register('F6', 'bennys', 'Ouvrir le menu bennys', function()
	if ESX.PlayerData.job and ESX.PlayerData.job.name == 'bennys' then
        OpenMenukbennys()
	end
end)

--- Blips

local pos = vector3(-202.82, -1324.78, 4.875902)
Citizen.CreateThread(function()
	local blip = AddBlipForCoord(pos)

	SetBlipSprite (blip, 446)
	SetBlipDisplay(blip, 4)
	SetBlipScale  (blip, 0.6)
	SetBlipColour (blip, 51)
	SetBlipAsShortRange(blip, true)

	BeginTextCommandSetBlipName('STRING')
	AddTextComponentSubstringPlayerName("~r~[Job] ~w~I Benny's")
	EndTextCommandSetBlipName(blip)
end)

-- kbennys by ! Kamion#1323